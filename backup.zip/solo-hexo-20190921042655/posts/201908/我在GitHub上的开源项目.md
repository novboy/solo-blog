title: 我在 GitHub 上的开源项目
date: '2019-08-23 04:16:54'
updated: '2019-08-23 04:16:54'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [xinge-cordova](https://github.com/novboy/xinge-cordova) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/novboy/xinge-cordova/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/novboy/xinge-cordova/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/novboy/xinge-cordova/network/members "分叉数")</span>

Cordova plugin for  腾讯信鸽 Tencent Xinge



---

### 2. [sencha-skin](https://github.com/novboy/sencha-skin) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/novboy/sencha-skin/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/novboy/sencha-skin/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/novboy/sencha-skin/network/members "分叉数")</span>

sencha-skin

